class Electronics{
		static class PowerBank{
				static class Mi{
					void show(){
							String Brand = "MI";
							String Colour = "Black";
							String ConnectorType = "USB,Micro USB";	
							String BatteryCapacity = "20000mAh";
							double price = 1799.00;
							System.out.println("Specification about MI Power Bank");
							System.out.println("Brand "+Brand);
							System.out.println("Colour " +Colour);
							System.out.println("ConnectorType "+ConnectorType);
							System.out.println("BatteryCapacity "+BatteryCapacity);
							System.out.println("Price "+price);
							System.out.println("");
						   }
						} // End of Mi class

				static class OnePlus{
					void show(){
							String Brand ="OnePlus";
							String Colour ="Black";
							String ConnectorType = "USB,Micro USB";
							String BatteryCapacity = "10000mAh";
							double price = 1099.00;	
							System.out.println("Specification about OnePlus Power Bank");
							System.out.println("Brand "+Brand);
							System.out.println("Colour " +Colour);
							System.out.println("ConnectorType "+ConnectorType);
							System.out.println("BatteryCapacity "+BatteryCapacity);
							System.out.println("Price "+price);
							System.out.println("");													
						     }
                                                 }// End of OnePlus class

                                       }// End of powerBank class

		static class Mobile{
				static class Samsung{
						static class Galaxy{
							static class M12{
								void show(){
									String Brand ="Samsung";
									String Model ="GalaxyM12";
									String Colour ="Blue";
									String MemoryCapacity="128GB";
									double price =11499.00;
									System.out.println("Specification about Samsung Galaxy M12");
							                System.out.println("Brand "+Brand);
									System.out.println("Model "+Model);
							                System.out.println("Colour " +Colour);
							                System.out.println("MemoryCapacity "+MemoryCapacity);
							                System.out.println("Price "+price);
									System.out.println("");
									}
								}//End of M12 Class
							static class A13{
								void show(){
									String Brand ="Samsung";
									String Model ="GalaxyA13";
									String Colour ="Blue";
									String MemoryCapacity="128GB";
									double price =18999.00;
									System.out.println("Specification about Samsung Galaxy A13");
							                System.out.println("Brand "+Brand);
									System.out.println("Model "+Model);
							                System.out.println("Colour " +Colour);
							                System.out.println("MemoryCapacity "+MemoryCapacity);
							                System.out.println("Price "+price);
									System.out.println("");
									}
								}// End of A13
                                                       } // End of Galaxy						
						}//End of Samsung
				
					static class Redmi{
							static class Note11{
								void show(){
									String Brand ="Redmi";
									String Model ="Note11";
									String Colour ="HorizonBlue";
									String MemoryCapacity="64GB";
									double price =13499.00;
									System.out.println("Specification about Redmi Note11");
							                System.out.println("Brand "+Brand);
									System.out.println("Model "+Model);
							                System.out.println("Colour " +Colour);
							                System.out.println("MemoryCapacity "+MemoryCapacity);
							                System.out.println("Price "+price);
									System.out.println("");
									} 
								} // End of Note11
							
							static class Sport9A{
								void show(){
									String Brand ="Redmi";
									String Model ="Sport9A";
									String Colour ="CarbonBlack";
									String MemoryCapacity="32GB";
									double price =7499.00;
									System.out.println("Specification about Redmi Sport9A");
							                System.out.println("Brand "+Brand);
									System.out.println("Model "+Model);
							                System.out.println("Colour " +Colour);
							                System.out.println("MemoryCapacity "+MemoryCapacity);
							                System.out.println("Price "+price);
									System.out.println("");
									}
								} // End of Sport9A

				 			}// End of Redmi
				}// End Mobile

		static class Laptop{
			static class Lenovo{
					void show(){
						String Brand = "Lenovo";
					        String Series = "Chromebook";
						String SpecificUses = "Multimedia,Personal,Business";
						String Os = "ChromeOS";
						String CPUManufacturer ="AMD";
						String ScreenSize = "15.6inches";
						double price = 39999.00;
						System.out.println("Specification about Lenovo laptop");
						System.out.println("Brand "+Brand);
						System.out.println("Series "+Series);
						System.out.println("SpecificUses "+SpecificUses);
						System.out.println("Os "+Os);
						System.out.println("CPUManufacturer "+CPUManufacturer);
						System.out.println("ScreenSize "+ScreenSize);
						System.out.println("Price "+price);
						System.out.println("");
						}
					}// End of Lenovo
			 static class Hp{
					void show(){
						String Brand = "HP";
					        String Series = "15s-gr0012AU";
						String SpecificUses = "Personal";
						String Os = "Windows10Home";
						String CPUManufacturer ="AMD";
						String ScreenSize = "15.6inches";
						double price = 41990.00;
						System.out.println("Specification about HP Laptop");
						System.out.println("Brand "+Brand);
						System.out.println("Series "+Series);
						System.out.println("SpecificUses "+SpecificUses);
						System.out.println("Os "+Os);
						System.out.println("CPUManufacturer "+CPUManufacturer);
						System.out.println("ScreenSize "+ScreenSize);
						System.out.println("Price "+price);
						System.out.println("");
						}
											
					}// End of HP
				} //End of Laptop

		static class Camera{
				static class DSLR{
					void show(){
						String Brand ="Canon";
						String FormFactor = "Handheld";
						String SkillLevel = "Amateur, Professional";
						String SpecialFeature = "Built-in monaural microphone,Sound-recording level adjustable,wind filter provided";
						String Colour = "Black";
						String JPEGQuality = "Basic,Fine,Normal";
						String WhiteBalanceSetting = "Auto";
						String ShootingMode = "Manual";
						double price = 36499.00;
						System.out.println("Specification about DSLR Camera");
						System.out.println("Brand "+Brand);
						System.out.println("FormFactor "+FormFactor);
						System.out.println("SkillLevel "+SkillLevel);
						System.out.println("Colour "+Colour);
						System.out.println("JPEGQuality "+JPEGQuality);
						System.out.println("WhiteBalanceSetting "+WhiteBalanceSetting);
						System.out.println("ShootingMode "+ShootingMode);
						System.out.println("SpecialFeature "+SpecialFeature);
						System.out.println("Price "+price);
						System.out.println("");
						}
                			} // End of DSLR
				static class DomeCamera{
					void show(){
						String Brand ="MI";
						String ConnectivityTechnology = "Wireless";
						String RecommendedFor = "Office,Garage,Kitchen,Room,StudyRoom";
						String FormFactor = "Dome";
						String ConnectivityProtocol = "Wi-Fi";
						String Model = "MJSXJ02CM";
						String SpecialFeature = "storageAI Motion Detection,Full HD resolution,360 degree view,Infrared Night Vision,";
						String PowerSource = "Corded Electric";
						double price = 2999.00;
						System.out.println("Specification about Dome Camera");
						System.out.println("Brand "+Brand);
						System.out.println("FormFactor "+FormFactor);
						System.out.println("ConnectivityTechnology "+ConnectivityTechnology);
						System.out.println("RecommendedFor "+RecommendedFor);
						System.out.println("ConnectivityProtocol "+ConnectivityProtocol);
						System.out.println("Model "+Model);
						System.out.println("SpecialFeature "+SpecialFeature);
						System.out.println("PowerSource "+PowerSource);
						System.out.println("Price "+price);
						System.out.println("");
						}
					} // End of DomeCamera
			} // End of Camera
		
   } // End of Electronic items



class Books{
	static class ActionAdventure{
			void show(){
				String Name = "The Complete Novels of Sherlock Holmes";
				String Author = "Sir Arthur Ignatius Conan Doyle";
				String Publisher = "Fingerprint! Publishing";
				String Language = "English";
				String Paperback = "536pages";
				String ItemWeight = "408G";
				String Dimensions = "20x14x4cm";
				double priceKindleEdition = 132.05;
				double pricePaperback = 139.00;
				System.out.println("Specifications of "+Name);
				System.out.println("Author "+Author);
				System.out.println("Publisher "+Publisher);
				System.out.println("Language "+Language);
				System.out.println("Paperback");
				System.out.println("ItemWeight"+ItemWeight);
				System.out.println("Dimensions "+Dimensions);
				System.out.println("PriceKindleEdition "+priceKindleEdition);
				System.out.println("PricePaperback "+pricePaperback);
				System.out.println("");
				}
			} // End of ActionAdventure

	static class Biographies{
			void show(){
				String Name = "Bose: The Untold Story of an Inconvenient Nationalist";
				String Author = "Chandrachur Ghose";
				String Publisher = "Penguin Viking ";
				String Language = "English";
				String Paperback = "740pages";
				String ItemWeight = "1KG20G";
				String Dimensions = "20.3 x 25.4 x 4.7 cm";
				double priceKindleEdition = 531.05;
				double pricePaperback = 559.00;
				System.out.println("Specification of  "+Name);
				System.out.println("Author "+Author);
				System.out.println("Publisher "+Publisher);
				System.out.println("Language "+Language);
				System.out.println("Paperback");
				System.out.println("ItemWeight"+ItemWeight);
				System.out.println("Dimensions "+Dimensions);
				System.out.println("PriceKindleEdition "+priceKindleEdition);
				System.out.println("PricePaperback "+pricePaperback);
				System.out.println("");	
				}
			}// End of Biographies
      } // End of Books


class MenFashion{
		static class Clothing{
			static class Shirts{
				void show(){
					String Name = "DennisLingo";
					String Manufacturer = "Swastik Creation";
					String Department ="Men";
					String ItemModelNumber = "C301_B-GREEN_S";
					String Colour = "Bottle Green";
					String FitType = "slim fit";
					String Size = "S,M,L,X,XL,2XL";
					String Sleeve = "Full";
					double price = 645.00;
					System.out.println("Specification "+Name);
					System.out.println("Manufacturer "+Manufacturer);
					System.out.println("Department "+Department);
					System.out.println("ItemModelNumber "+ItemModelNumber);
					System.out.println("Colour "+Colour);
					System.out.println("FitType "+FitType);
					System.out.println("Size "+Size);
					System.out.println("Sleeve "+Sleeve);
					System.out.println("Price "+price);
					System.out.println("");
					}
                            }// End of Shirts
			static class Jeans{
				void show(){
					String Name = "Levi's Men's Slim Jeans";
					String Manufacturer = "KENPARK BANGLADESH (PVT) LTD";
					String Department = "Men";
					String ItemModelNumber = "18298-1103";
					String Material = "Cotton";
					String Colour = "Blue";
					String FitType = "Regular";
					String Size ="28,30,32,34,36,38,40,42";
					double price = 2499.00;
					System.out.println("Specification of "+Name);
					System.out.println("Manufacturer "+Manufacturer);
					System.out.println("Department "+Department);
					System.out.println("ItemModelNumber "+ItemModelNumber);
					System.out.println("Material "+Material);
					System.out.println("Colour "+Colour);
					System.out.println("FitType "+FitType);
					System.out.println("Size "+Size);
					System.out.println("Price "+price);
					System.out.println("");
					}
				} // End of class Jeans				
			}// End Of Class Clothing

		static class Shoes{
			static class Boots{
				void show(){
					String Name = "Kraasa4273";
					String Manufacturer = "Kraasa";
					String Department = "Men";
					String ItemModelNumber = "CA4273-Black";
					String Material = "synthetic leather";
					String Sole = "Polyvinyl Chloride";
					String Closure = "Lace-Up";
					String Size = "6,7,8,9,10,11 UK";
					String Width = "Medium";
					String Feature = "LightWeight";
					double price = 599.00;
					System.out.println("Specification of "+Name);
					System.out.println("Manufacturer "+Manufacturer);
					System.out.println("Department "+Department);
					System.out.println("ItemModelNumber "+ItemModelNumber);
					System.out.println("Material "+Material);
					System.out.println("Sole "+Sole);
					System.out.println("Closure "+Closure);
					System.out.println("Size "+Size);
					System.out.println("Width "+Width);
					System.out.println("Feature "+Feature);
					System.out.println("price "+price);
					System.out.println("");
					}
			}// End of boots
			
			static class Formal{
				void show(){
					String Name = "MAEVE&SHELBY";
					String Manufacturer = "MAEVE & SHELBY";
					String Department = "Men";
					String ItemModelNumber = " 96-10267";
					String Material = "synthetic leather";
					String Sole = "Polyvinyl Chloride";
					String Closure = "Lace-Up";
					String Size = "6,7,8,9,10,11 UK";
					String Width = "Narrow";
					String Feature = "LightWeight";
					double price = 799.00;
					System.out.println("Specification of  "+Name);
					System.out.println("Manufacturer "+Manufacturer);
					System.out.println("Department "+Department);
					System.out.println("ItemModelNumber "+ItemModelNumber);
					System.out.println("Material "+Material);
					System.out.println("Sole "+Sole);
					System.out.println("Closure "+Closure);
					System.out.println("Size "+Size);
					System.out.println("Width "+Width);
					System.out.println("Feature "+Feature);
					System.out.println("price "+price);
					System.out.println("");
					}
				}// End of class Formal
		} // End of Class Shoes
	
}// End of class MenFashion



class WomenFashion{
		static class clothing{
			static class Saree{
				void show(){
					String Name = "ANNI DESIGNER Saree";
					String Manufacturer = "ANNI DESIGNER";
					String Department ="Women";
					String ItemModelNumber = "ANGMANCH-NAVY BLUE-STYLE";
					String Colour = "Blue";
					String SareeFabric = "ArtSilk,BlouseFabric";
					double SareeLength = 5.50;
					double price = 645.00;
					System.out.println("Specification "+Name);
					System.out.println("Manufacturer "+Manufacturer);
					System.out.println("Department "+Department);
					System.out.println("ItemModelNumber "+ItemModelNumber);
					System.out.println("Colour "+Colour);
					System.out.println("SareeFabric "+SareeFabric);
					System.out.println("SareeLength "+SareeLength);
					System.out.println("Price "+price);
					System.out.println("");
					}				
				}// End of class saree
		      static class Kurtas{
				void show(){
					String Name = "Janasy Kurtis";
					String Manufacturer = "Threadbucket Studio LLP";
					String Department ="Women";
					String ItemModelNumber = "JNE3567-KR-XS";
					String Colour = "Pink";
					String FitType = "Regular fit";
					String Size = "XS,S,M,L,X,XL,2XL";
					String Sleeve = "Full";
					double price = 430.00;
					System.out.println("Specification of "+Name);
					System.out.println("Manufacturer "+Manufacturer);
					System.out.println("Department "+Department);
					System.out.println("ItemModelNumber "+ItemModelNumber);
					System.out.println("Colour "+Colour);
					System.out.println("FitType "+FitType);
					System.out.println("Size "+Size);
					System.out.println("Sleeve "+Sleeve);
					System.out.println("Price "+price);
					System.out.println("");
					}
			  }// End of Kurtas
		}// End of clothing

		
	  static class Shoes{
		   static class Formal{
			     void show(){
					String Name = "Footshez";
					String Manufacturer = "Footshez";
					String Department = "Women";
					String ItemModelNumber = "F-079BLACK";
					String Material = "synthetic";
					String Sole = "Polyvinyl Chloride";
					String Closure = "Lace-Up";
					String Size = "3,4,6,7,8, UK";
					String Width = "Narrow";
					String Feature = "LightWeight";
					double price = 519.00;
					System.out.println("Name "+Name);
					System.out.println("Manufacturer "+Manufacturer);
					System.out.println("Department "+Department);
					System.out.println("ItemModelNumber "+ItemModelNumber);
					System.out.println("Material "+Material);
					System.out.println("Sole "+Sole);
					System.out.println("Closure "+Closure);
					System.out.println("Size "+Size);
					System.out.println("Width "+Width);
					System.out.println("Feature "+Feature);
					System.out.println("price "+price);
					System.out.println("");							
					}
				}// End of Formal shoes
		
			static class Sports{
				void show(){
					String Name = "AlexaRunningShoes";
					String Manufacturer = "Campus";
					String Department = "Women";
					String ItemModelNumber = "5G-663";
					String Material = "Mesh";
					String Sole = "Polyvinyl Chloride";
					String Closure = "Lace-Up";
					String Size = "4,5,6,7,8, UK";
					String Width = "Medium";
					String Feature = "LightWeight";
					double price = 1631.00;
					System.out.println("Name "+Name);
					System.out.println("Manufacturer "+Manufacturer);
					System.out.println("Department "+Department);
					System.out.println("ItemModelNumber "+ItemModelNumber);
					System.out.println("Material "+Material);
					System.out.println("Sole "+Sole);
					System.out.println("Closure "+Closure);
					System.out.println("Size "+Size);
					System.out.println("Width "+Width);
					System.out.println("Feature "+Feature);
					System.out.println("price "+price);
					System.out.println("");
					}
			} // End of sports class
		} // End of shoes
	
         } // End of Women Fashion



class Amazon{
	public static void main(String []args){
			Electronics.PowerBank.Mi powerbankmi = new Electronics.PowerBank.Mi();
				            powerbankmi.show();


			Electronics.PowerBank.OnePlus powerbankoneplus = new Electronics.PowerBank.OnePlus();
						powerbankoneplus.show();


			Electronics.Mobile.Samsung.Galaxy.M12 samm12 = new Electronics.Mobile.Samsung.Galaxy.M12();
						samm12.show();


			Electronics.Mobile.Samsung.Galaxy.A13 sama13 = new Electronics.Mobile.Samsung.Galaxy.A13();
						sama13.show();

			
			
			Electronics.Mobile.Redmi.Note11 redminote11 = new Electronics.Mobile.Redmi.Note11();
						redminote11.show();



			
  			Electronics.Mobile.Redmi.Sport9A redmisport9a = new Electronics.Mobile.Redmi.Sport9A();
						redmisport9a.show();

		
			
	
			Electronics.Laptop.Lenovo laplen = new Electronics.Laptop.Lenovo();
					laplen.show();


			Electronics.Laptop.Hp laphp = new Electronics.Laptop.Hp();
					laphp.show();

			Books.ActionAdventure baa = new Books.ActionAdventure();
				baa.show();

			Books.Biographies bb = new Books.Biographies();
				bb.show();
}

}

	
		
		


